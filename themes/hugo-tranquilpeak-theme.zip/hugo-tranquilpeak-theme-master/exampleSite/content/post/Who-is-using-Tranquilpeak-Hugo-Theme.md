---
title: "Who's using Tranquilpeak Hugo Theme"
slug: who-is-using-tranquilpeak-hugo-theme
date: 2015-06-14
categories:
- tranquilpeak
- showcase
thumbnailImagePosition: left
thumbnailImage: //d1u9biwaxjngwg.cloudfront.net/cover-image-showcase/city-750.jpg
---

Here you can find a list of the blogs that use Tranquilpeak theme, with different styles and customizations.

<!--more-->

If you want to add your site to this showcase, click [here](https://github.com/kakawait/hugo-tranquilpeak-theme/issues/new?title=Add%20my%20blog%20into%20the%20showcase&body=Hey,%20add%20my%20blog%20into%20the%20showcase:) and fill the following information:

- public url
- name (optional)
- description (optional)


## Eric Bouchut's blog

[![Eric Bouchut's blog](http://i.imgur.com/zQmKIKNm.png)](http://ericbouchut.com/)

## Robin Hu's blog

[![Robin Hu's blog](https://i.imgur.com/7SujaMam.png)](http://robinforest.net/)

## Zentechnista's blog

[![Zentechnista's blog](https://i.imgur.com/7zN7WMMm.png)](https://zentechnista.github.io/)

## Viajes Dendarii's blog

[![Viajes Dendarii's blog](https://i.imgur.com/tdXK3kYm.png)](https://dendarii.es)

## Wajahat Karim's blog

[![Wajahat Karim's blog](https://i.imgur.com/9BPoJvdm.png)](https://wajahatkarim.com/)

## Xiaoyun Yang's blog

[![Xiaoyun Yang's blog](https://i.imgur.com/vVRSvhpm.png)](http://xiaoyunyang.github.io/)

## Alfred E. Lin's blog

[![Alfred E. Lin's blog](https://i.imgur.com/lHwsvIJm.png)](http://alfredlin.com/)

## Philipp Gärtner's blog

[![Philipp Gärtner's blog](https://i.imgur.com/Sx6oXnSm.png)](https://philippgaertner.github.io/)

## Sagar Khatri's blog

[![Sagar Khatri's blog](https://i.imgur.com/edZ3PO9m.png)](https://www.ragasirtahk.tk/)

## Dr. Cruz Rincón's blog

[![Dr. Cruz Rincón's blog](https://i.imgur.com/XazQAolm.png)](https://www.cruzrincon.com.ve/)

## Björn Oettinghaus's blog

[![Björn Oettinghaus's blog](https://i.imgur.com/8vSMWIam.png)](https://www.datisticsblog.com/)

## Ivan Fadila Putra's blog

[![Ivan Fadila Putra's blog](https://i.imgur.com/r7tJa2Lm.png)](https://ffadilaputra.github.io/)

## BALLOON a.k.a. Fu-sen's blog

[![BALLOON a.k.a. Fu-sen's blog](https://i.imgur.com/ThaDHyfm.png)](https://balloon.gq/)

## Yue Hao's blog

[![Yue Hao's blog](https://i.imgur.com/CDDrTr4m.png)](https://yueyvettehao.netlify.com/)

## Adrian Riyadi's blog

[![Adrian Riyadi's blog](https://i.imgur.com/s6yB9lFm.png)](https://blog.adrian.id/)

## Vijay Mateti's blog

[![Vijay Mateti's blog](https://i.imgur.com/8LMItYSm.png)](https://vijaymateti.com/)

## Walid Benchaa's blog

[![Walid Benchaa's blog](https://i.imgur.com/8yn9DaOm.png)](https://rekkodo.gitlab.io/)

## Stella Wang's blog

[![Stella Wang's blog](https://i.imgur.com/F0jVpsOm.png)](https://hiwanglong.github.io/)

## Aditya Mangal's blog

[![Aditya Mangal's blog](https://i.imgur.com/FKrnNGlm.png)](https://www.adityamangal.com/)
